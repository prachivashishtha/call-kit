module.exports = {
	trailingComma: 'es5',
	tabWidth: 4,
	useTabs: true,
	semi: true,
	singleQuote: true,
	bracketSpacing: true,
	// ignorePath: '.prettierignore',
	// eslintIntegration: false,
	// tslintIntegration: false,
	// 'workingDirectories': [{ "pattern": "./packages/IM/sdk" }]
};