export const appKey = '41960726#1129223'
export const appId = 'f3d98482b58a416e881ce5378f7be22e'